/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.part1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class RegisterTest {
    

     @Test
    public void testCheckUserName() {
        Register register = new Register();
        register.username = "kyl_1"; // Simulating user input
        assertTrue(register.checkUserName());

        register.username = "kyle!!!!!!!"; // Invalid username
        assertFalse(register.checkUserName());

        register.username = "kyl"; // Valid username
        assertFalse(register.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity() {
        Register register = new Register();
        
        register.password = "Ch&&sec@ke99!"; // Valid password
        assertTrue(register.checkPasswordComplexity());
        
        register.password = "password"; // Invalid password
        assertFalse(register.checkPasswordComplexity());
        
        register.password = "Pass123"; // Invalid password (no special character)
        assertFalse(register.checkPasswordComplexity());
    }

    @Test
    public void testLoginUser() {
        Register register = new Register();
        register.username = "test_";
        register.password = "TestPassword1!";

        assertTrue(register.loginUser("test_", "TestPassword1!")); // Valid login
        assertFalse(register.loginUser("test_", "wrong_password")); // Wrong password
        assertFalse(register.loginUser("wrong_username", "TestPassword1!")); // Wrong username
    }

    
    
    // Additional test for registerUser method
    @Test
    public void testRegisterUser() {
        Register register = new Register();
        
        // Simulating user registration
        register.username = "test_";
        register.password = "TestPassword1!";
        register.name = "Test";
        register.surname = "User";
        
        // Ensure the username and password are set correctly
        assertTrue(register.checkUserName());
        assertTrue(register.checkPasswordComplexity());
        
        assertEquals("Registration successful!", "Registration successful!"); // Assuming you will add this message logic

        // Test invalid username
        register.username = "testName"; // Invalid username
        assertFalse(register.checkUserName());

        // Test invalid password
        register.password = "password"; // Invalid password
        assertFalse(register.checkPasswordComplexity());
    }
}