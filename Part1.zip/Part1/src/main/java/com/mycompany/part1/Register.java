package com.mycompany.part1;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class Register {
      String name;
     String surname;
    String username;
    String password;

  

    // Method to prompt user for registration details
    public void registerUser() {
        Scanner scanner = new Scanner(System.in);
        // Prompt user for name and surname
        System.out.print("Enter your name: ");
        name = scanner.nextLine();
        
        System.out.print("Enter your surname: ");
        surname = scanner.nextLine();
        
        // Prompt user for username
        System.out.print("Enter a username (5 or fewer characters, containing an underscore): ");
        username = scanner.nextLine();
        while (!checkUserName()) {
            System.out.print("Invalid username! Enter a username (5 or fewer characters, containing an underscore): ");
            username = scanner.nextLine();
        }

        // Prompt user for password
        System.out.print("Enter a password (8 or more characters, containing a digit, capital letter, and special character): ");
        password = scanner.nextLine();
        while (!checkPasswordComplexity()) {
            password = scanner.nextLine();
        }

        System.out.println("Registration successful!");
    }

    // Method to prompt user for login details in a loop
    public void logIn() {
        Scanner scanner = new Scanner(System.in);
        boolean loggedIn = false;

        while (!loggedIn) {
            System.out.print("Enter your username: ");
            String inputUsername = scanner.nextLine();
            System.out.print("Enter your password: ");
            String inputPassword = scanner.nextLine();

            loggedIn = loginUser(inputUsername, inputPassword);
            System.out.println(returnLoginStatus(loggedIn));

            // Ask if the user wants to try again
            if (!loggedIn) {
                System.out.print("Would you like to try again? (yes/no): ");
                String retryResponse = scanner.nextLine();
                if (!retryResponse.equalsIgnoreCase("yes")) {
                    break; // Exit the loop if the user chooses not to try again
                }
            }
        }
    }

    // Method to check if the username meets criteria
    boolean checkUserName() {
        boolean containsUnderscore = username != null && username.contains("_");
        boolean validLength = username != null && username.length() <= 5;

        return containsUnderscore && validLength;
    }

    // Method to check if the password meets complexity requirements
    public boolean checkPasswordComplexity() {
        if (password == null) return false;

        boolean hasUpperCase = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpperCase = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if ("!@#$%^&*()".indexOf(c) != -1) {
                hasSpecialCharacter = true;
            }
        }

        return password.length() >= 8 && hasUpperCase && hasNumber && hasSpecialCharacter;
    }

    // Method to check if a user can successfully log in
    public boolean loginUser(String inputUsername, String inputPassword) {
        return this.username != null && this.username.equals(inputUsername) && this.password != null && this.password.equals(inputPassword);
    }

    // Method to return login status message
    // Method to return login status message
    public String returnLoginStatus(boolean successful) {
        if (successful) {
            return "Login successful!\n Welcome "+ name+ " "+ surname + ", it is great to see you again!";
        } else {
            return "Login failed. Please check your username and password and try again.";
        }
    }
}