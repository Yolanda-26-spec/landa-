package com.mycompany.part1;

public class Part1 {
    public static void main(String[] args) {
        Register login = new Register();

        // Register a new user
        login.registerUser();

        // Attempt to log in with a loop
        login.logIn();
    }
}
// Register login = new Register();
//
//        // Register a new user
//        login.registerUser();
//
//        // Attempt to log in with a loop
//        login.logIn();